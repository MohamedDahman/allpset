package at.refugeecode.dutchman;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DutchmanApplication {

	public static void main(String[] args) {
		SpringApplication.run(DutchmanApplication.class, args);
	}
}
