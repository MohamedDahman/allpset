package at.refugeecode.jacksparrow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JacksparrowApplication {

	public static void main(String[] args) {
		SpringApplication.run(JacksparrowApplication.class, args);
	}
}
