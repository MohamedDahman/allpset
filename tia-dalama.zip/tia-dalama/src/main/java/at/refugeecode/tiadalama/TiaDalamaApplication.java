package at.refugeecode.tiadalama;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiaDalamaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiaDalamaApplication.class, args);
	}
}
